package accessmodifierpack2;
import accessmodifierpack1.*;

public class accessspecifiers4 {

	public static void main(String[] args) {
		
		pubaccessspecifiers obj = new pubaccessspecifiers(); 
        obj.display();  
		
	}
}
