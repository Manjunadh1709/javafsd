package methods;
//method demo
public class methodExecution {

public int multipynumbers(int a,int b) {
	int c=a*b;
	return c;
}

public static void main(String[] args) {

	methodExecution b=new methodExecution();
	int ans= b.multipynumbers(5,9);
	System.out.println("Multipilcation is :"+ans);
	}
}