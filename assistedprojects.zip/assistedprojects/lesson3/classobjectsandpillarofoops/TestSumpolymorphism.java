package classobjectsandpillarofoops;
class TestSumpolymorphism 
{
    public int sum(int x, int y) 
    { 
        return (x + y); 
    } 
    public int sum(int x, int y, int z) 
    { 
        return (x + y + z); 
    } 
    public double sum(double x, double y) 
    { 
        return (x + y); 
    } 
    public static void main(String args[]) 
    { 
        TestSumpolymorphism s = new TestSumpolymorphism(); 
        System.out.println(s.sum(100, 200)); 
        System.out.println(s.sum(100, 200, 300)); 
        System.out.println(s.sum(100.5, 200.5)); 
    } 
}
