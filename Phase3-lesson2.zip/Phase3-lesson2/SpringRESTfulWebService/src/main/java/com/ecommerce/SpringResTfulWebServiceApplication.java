package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringResTfulWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringResTfulWebServiceApplication.class, args);
		System.out.println("Server Up!...");
	}

}
