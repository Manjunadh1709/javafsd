package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;

@EnableKafka
@SpringBootApplication
@ComponentScan("com")
public class ApacheKafkaApplication {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    
	public static void main(String[] args) {
		SpringApplication.run(ApacheKafkaApplication.class, args);
		System.out.println("Kafka Server Up!...");
	}

	@KafkaListener(topics="GENERAL",groupId="group-id")
	public void listne(String message) {
		System.out.println("Message  received: "+message);
	}
}
