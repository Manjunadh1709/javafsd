package com.example.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.example.test")
public class RestapiOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapiOneApplication.class, args);
		System.out.println("Server Up!...");
	}

}
