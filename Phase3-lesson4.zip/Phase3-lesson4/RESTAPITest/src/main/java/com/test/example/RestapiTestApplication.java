package com.test.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapiTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapiTestApplication.class, args);
		System.out.println("Server up!...");
	}

}
