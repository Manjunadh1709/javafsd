package com;
public class Binarysearch {

    public static  void main(String[] args){


        int[] arr = {3,6,9,12,15};
        int key = 15;
        int arrlength = arr.length;
        Binarysearch(arr,0,key,arrlength);
    }

public static void Binarysearch(int array[], int low, int x, int high){

        int midValue = (low+high)/2;
        while(low<=high){

            if(array[midValue]<x){

                low = midValue + 1;
            } else if(array[midValue]==x){
                System.out.println("Element is found at index :"+midValue);
                break;
            }else {

                high=midValue-1;
            }
            midValue = (low+high)/2;
        }
            if(low>high){

                System.out.println("Element is not found");
            }

}

}
