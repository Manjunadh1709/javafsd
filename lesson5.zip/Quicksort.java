package com;
public class Quicksort{ 
    int partition(int array[], int low, int high){
        int pivot = array[high];
        int i = (low-1); 
        for (int j=low; j<high; j++) { 
            if (array[j] <= pivot)
            {
                i++;
                // swap array[i] and array[j]
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
        // swap array[i+1] and array[high] (or pivot)
        int temp = array[i+1];
        array[i+1] = array[high];
        array[high] = temp;
        return i+1;
    }
    void sort(int array[], int low, int high)
    {
        if (low < high)
        {
            int pi = partition(array, low, high);         
            sort(array, low, pi-1);
            sort(array, pi+1, high);
        }
    }
    static void printArray(int array[])
    {
        int n = array.length;
        for (int i=0; i<n; ++i)
            System.out.print(array[i]+" ");
        System.out.println();
    }
    // Driver program
    public static void main(String args[])
    {
        int array[] = {11, 7, 18, 6, 1, 15};
        int n = array.length;
        Quicksort ob = new Quicksort();
        ob.sort(array, 0, n-1);
        System.out.println("sorted array is");
        printArray(array);
    }
}