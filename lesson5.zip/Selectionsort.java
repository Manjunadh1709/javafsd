package com;
public class Selectionsort {

    public static void main(String[] args) {

    int array[] = {9,6,3,1,2,4,5,8,7};
    int length = array.length;
    Selectionsort(array);
    System.out.println("The sorted elements are:");
    for(int i:array){

        System.out.println(i);
         }
     }

    public static void Selectionsort(int array[]){

        for(int i=0;i<array.length-1;i++){

            int index =i;
            for(int j=i+1;j<array.length;j++){
                if(array[j]<array[index]){

                    index =j;
                }

            }
            int smallNumber = array[index];
            array[index]= array[i];
            array[i]= smallNumber;
        }

    }
}
