package com;
class RotateArray { 
public void rotate(int[] numbers, int p) {
    		if(p > numbers.length) 
       			p=p%numbers.length;
 		int[] result = new int[numbers.length];
 		for(int i=0; i < p; i++){
        			result[i] = numbers[numbers.length-p+i];
 		}
 		int j=0;
    		for(int i=p; i<numbers.length; i++){
        			result[i] = numbers[j];
j++;
    		}
 		System.arraycopy( result, 0, numbers, 0, numbers.length );
}
} 
public class Arrayrotation
{
	public static void main(String[] args) {
		RotateArray r = new RotateArray();
        		int arr[] = { 11, 12, 13, 14, 15, 16, 17 }; 
        		r.rotate(arr, 5); 
        		for(int i=0;i<arr.length;i++){
            			System.out.print(arr[i]+" ");
        		}
	}
}
